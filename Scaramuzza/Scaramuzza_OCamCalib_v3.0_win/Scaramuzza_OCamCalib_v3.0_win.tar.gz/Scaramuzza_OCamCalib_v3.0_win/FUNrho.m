function w=FUNrho(ss,rho)


w=polyval(ss(end:-1:1), rho );